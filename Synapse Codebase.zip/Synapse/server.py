import os
import asyncio
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv()

ASSISTANT_ID = os.getenv("OPENAI_ASSISTANT_ID")
QUESTIONS_DIR = Path("questions")
client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

app = FastAPI(title="Synapse API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeRequest(BaseModel):
    company: str


async def run_question(question: str, index: int, total: int) -> dict:
    try:
        thread = await client.beta.threads.create()
        await client.beta.threads.messages.create(
            thread_id=thread.id, role="user", content=question
        )
        run = await client.beta.threads.runs.create_and_poll(
            thread_id=thread.id, assistant_id=ASSISTANT_ID
        )
        if run.status == "completed":
            messages = await client.beta.threads.messages.list(thread_id=thread.id)
            return {
                "index": index,
                "question": question,
                "response": messages.data[0].content[0].text.value,
                "status": "success"
            }
        raise Exception(f"Run status: {run.status}")
    except Exception as e:
        return {
            "index": index,
            "question": question,
            "response": None,
            "status": "error",
            "error": str(e)
        }


def load_questions(company: str) -> list:
    file_path = QUESTIONS_DIR / f"{company}.json"
    if not file_path.exists():
        raise HTTPException(404, f"Questions file not found for company: {company}")
    with open(file_path) as f:
        return json.load(f)


def parse_flags(result: dict) -> list:
    try:
        parsed = json.loads(result["response"])
        flags = parsed if isinstance(parsed, list) else parsed.get("red_flags", [parsed])
        return [
            {
                "index": result["index"],
                "question": result["question"],
                "tier": flag.get("tier"),
                "category": ", ".join(flag.get("category", "").split("|")[:3]) if flag.get("category") else None,
                "flag_type": flag.get("flag_type"),
                "entity": flag.get("entity"),
                "call_q2_evidence": flag.get("call_q2_evidence"),
                "call_q3_evidence": flag.get("call_q3_evidence"),
                "delta": flag.get("delta"),
                "confidence": flag.get("confidence"),
            }
            for flag in flags
        ]
    except:
        return [{
            "index": result["index"],
            "question": result["question"],
            "tier": None, "category": None, "flag_type": None, "entity": None,
            "call_q2_evidence": None, "call_q3_evidence": None, "delta": None, "confidence": None,
        }]


@app.post("/analyze")
async def analyze(req: AnalyzeRequest):
    questions = load_questions(req.company)
    total = len(questions)
    batch_size = 20
    total_batches = (total + batch_size - 1) // batch_size
    results = []

    print(f"Starting analysis for {req.company}: {total} questions in {total_batches} batches")
    for batch_num in range(total_batches):
        start_idx = batch_num * batch_size
        end_idx = min(start_idx + batch_size, total)
        tasks = [run_question(q, start_idx + i, total) for i, q in enumerate(questions[start_idx:end_idx])]
        batch_results = await asyncio.gather(*tasks)
        results.extend(batch_results)
        print(f"Batch {batch_num + 1}/{total_batches} completed")

    results = sorted(results, key=lambda x: x["index"])
    flags = []
    for r in results:
        flags.extend(parse_flags(r))
    tier1_flags = [f for f in flags if f["tier"] == 1]
    confidence_order = {"high": 3, "medium": 2, "low": 1}
    return sorted(tier1_flags, key=lambda x: confidence_order.get((x["confidence"] or "").lower(), 0))


@app.get("/health")
async def health():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
