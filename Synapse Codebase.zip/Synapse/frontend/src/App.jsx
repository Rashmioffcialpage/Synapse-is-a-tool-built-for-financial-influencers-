import React, { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp, Filter, Search, Play, X, Loader2 } from 'lucide-react';

const API_URL = 'http://localhost:8000';

const companies = [
  { id: 'amgen', label: 'Amgen 2025 Q2 vs Q3' },
  { id: 'novartis', label: 'Novartis 2025 Q2 vs Q3' },
  { id: 'bms', label: 'BMS 2025 Q2 vs Q3' },
];

const tierConfig = {
  1: { label: 'Tier 1: Critical', color: '#dc2626', bg: '#fef2f2', border: '#fecaca' },
  2: { label: 'Tier 2: High Priority', color: '#d97706', bg: '#fffbeb', border: '#fde68a' },
  3: { label: 'Tier 3: Sentiment', color: '#7c3aed', bg: '#f5f3ff', border: '#e9d5ff' },
  4: { label: 'Tier 4: Disclosure', color: '#6b7280', bg: '#f9fafb', border: '#e5e7eb' }
};

const confidenceConfig = {
  'High': { color: '#dc2626', bg: '#fef2f2' },
  'Medium': { color: '#d97706', bg: '#fffbeb' },
  'Low': { color: '#6b7280', bg: '#f9fafb' }
};

export default function App() {
  const [flags, setFlags] = useState([]);
  const [expandedFlags, setExpandedFlags] = useState(new Set());
  const [selectedCompany, setSelectedCompany] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPodcast, setShowPodcast] = useState(false);
  const [filters, setFilters] = useState({
    tier: 'all',
    category: 'all',
    confidence: 'all',
    search: ''
  });
  const [sortConfig, setSortConfig] = useState({ key: 'tier', direction: 'asc' });

  const handleAnalyze = async () => {
    if (!selectedCompany) return;
    setLoading(true);
    setFlags([]);
    try {
      const res = await fetch(`${API_URL}/analyze`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company: selectedCompany })
      });
      const data = await res.json();
      setFlags(data.map((f, i) => ({ ...f, id: i + 1 })));
    } catch (err) {
      console.error('Analysis failed:', err);
    } finally {
      setLoading(false);
    }
  };

  const toggleFlag = (id) => {
    const newExpanded = new Set(expandedFlags);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedFlags(newExpanded);
  };

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const filteredAndSortedFlags = flags
    .filter(flag => {
      if (filters.tier !== 'all' && flag.tier !== parseInt(filters.tier)) return false;
      if (filters.category !== 'all' && flag.category !== filters.category) return false;
      if (filters.confidence !== 'all' && flag.confidence !== filters.confidence) return false;
      if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        return (
          (flag.entity || '').toLowerCase().includes(searchLower) ||
          (flag.flag_type || '').toLowerCase().includes(searchLower) ||
          (flag.delta || '').toLowerCase().includes(searchLower)
        );
      }
      return true;
    })
    .sort((a, b) => {
      const aVal = a[sortConfig.key];
      const bVal = b[sortConfig.key];
      if (sortConfig.direction === 'asc') {
        return aVal > bVal ? 1 : -1;
      } else {
        return aVal < bVal ? 1 : -1;
      }
    });

  const tierCounts = flags.reduce((acc, flag) => {
    acc[flag.tier] = (acc[flag.tier] || 0) + 1;
    return acc;
  }, {});

  const categories = [...new Set(flags.map(f => f.category))];

  return (
    <div style={{ 
      fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      background: '#f9fafb', 
      minHeight: '100vh',
      color: '#111827'
    }}>
      {/* Header */}
      <header style={{ 
        background: '#ffffff', 
        borderBottom: '2px solid #e5e7eb',
        padding: '20px 32px',
        position: 'sticky',
        top: 0,
        zIndex: 100,
        boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
      }}>
        <div style={{ 
          maxWidth: 1400, 
          margin: '0 auto',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <h1 style={{ 
              fontSize: 24, 
              fontWeight: 700,
              color: '#111827',
              margin: '0 0 4px 0',
              letterSpacing: '-0.5px'
            }}>Synapse</h1>
            <div style={{ 
              fontSize: 12,
              color: '#6b7280',
              fontWeight: 500
            }}>Pharma Earnings Call Red Flag Detector</div>
          </div>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <select
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              style={{
                padding: '10px 16px',
                background: '#fff',
              color: '#374151',
              border: '1px solid #d1d5db',
              borderRadius: 6,
              fontSize: 13,
              fontWeight: 500,
                cursor: 'pointer',
                minWidth: 220
              }}
            >
              <option value="">Select Company...</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>{c.label}</option>
              ))}
            </select>
            {flags.length === 0 ? (
              <button 
                onClick={handleAnalyze}
                disabled={!selectedCompany || loading}
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 8,
                  padding: '10px 24px',
                  background: selectedCompany && !loading ? '#111827' : '#9ca3af',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 6,
                  fontSize: 13,
                  fontWeight: 500,
                  cursor: selectedCompany && !loading ? 'pointer' : 'not-allowed'
                }}
              >
                {loading ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
                {loading ? 'Thinking...' : 'Go'}
              </button>
            ) : (
              <button 
                onClick={() => setShowPodcast(true)}
                style={{ 
                  display: 'flex', 
                  alignItems: 'center', 
                  gap: 8,
                  padding: '10px 24px',
                  background: '#7c3aed',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 6,
                  fontSize: 13,
                  fontWeight: 500,
                  cursor: 'pointer'
                }}
              >
                🎙️ Create Podcast
              </button>
            )}
          </div>
        </div>
      </header>

      <div style={{ display: 'flex', maxWidth: showPodcast ? 'none' : 1400, margin: '0 auto' }}>
      <main style={{ flex: 1, padding: '32px', minWidth: 0 }}>
        
        {/* Company Header */}
        {selectedCompany && (
          <div style={{ marginBottom: 24 }}>
            <div style={{
              fontSize: 12,
              color: '#6b7280',
              textTransform: 'uppercase',
              letterSpacing: '0.5px',
              marginBottom: 12,
              fontWeight: 600
            }}>
              Earnings Call Analysis
            </div>
            <h1 style={{
              fontSize: 32,
              fontWeight: 600,
              margin: '0 0 12px 0',
              color: '#111827',
              letterSpacing: '-0.5px'
            }}>
              {companies.find(c => c.id === selectedCompany)?.label}
            </h1>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12,
              fontSize: 15,
              color: '#374151'
            }}>
              {flags.length > 0 && (
                <>
                  <span style={{ color: '#9ca3af' }}>·</span>
                  <span style={{
                    color: tierCounts[1] > 0 ? '#dc2626' : tierCounts[2] > 0 ? '#d97706' : '#6b7280',
                    fontWeight: 600
                  }}>{flags.length} flags detected</span>
                </>
              )}
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div style={{
            background: '#ffffff',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
            padding: '60px 24px',
            marginBottom: 24,
            textAlign: 'center'
          }}>
            <Loader2 size={32} style={{ animation: 'spin 1s linear infinite', color: '#6b7280', marginBottom: 16 }} />
            <p style={{ fontSize: 14, color: '#6b7280', margin: 0 }}>
              Thinking... This may take a few seconds.
            </p>
          </div>
        )}

        {/* Empty State */}
        {!loading && flags.length === 0 && (
          <div style={{
            background: '#ffffff',
            border: '1px solid #e5e7eb',
            borderRadius: 8,
            padding: '80px 24px',
            textAlign: 'center'
          }}>
            <img src="/synapse.png" alt="Synapse" style={{ width: 120, height: 120, marginBottom: 16 }} />
            <h3 style={{ fontSize: 18, fontWeight: 600, color: '#374151', margin: '0 0 8px 0' }}>
              Ready to Find the Red Flags?
            </h3>
            <p style={{ fontSize: 14, color: '#6b7280', margin: 0 }}>
              Select a company from the dropdown and click "Go" to analyze earnings calls.
            </p>
          </div>
        )}

        {/* Filters */}
        {flags.length > 0 && <div style={{
          background: '#ffffff',
          border: '1px solid #e5e7eb',
          borderRadius: 8,
          padding: '20px',
          marginBottom: 24,
          display: 'flex',
          gap: 16,
          flexWrap: 'wrap',
          alignItems: 'center'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#6b7280' }}>
            <Filter size={16} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>Filters:</span>
          </div>
          
          <select
            value={filters.tier}
            onChange={(e) => setFilters({ ...filters, tier: e.target.value })}
            style={{
              padding: '8px 12px',
              border: '1px solid #d1d5db',
              borderRadius: 6,
              fontSize: 13,
              background: '#fff',
              cursor: 'pointer'
            }}
          >
            <option value="all">All Tiers</option>
            {[1, 2, 3, 4].map(tier => (
              <option key={tier} value={tier}>{tierConfig[tier].label}</option>
            ))}
          </select>

          <select
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            style={{
              padding: '8px 12px',
              border: '1px solid #d1d5db',
              borderRadius: 6,
              fontSize: 13,
              background: '#fff',
              cursor: 'pointer'
            }}
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          <select
            value={filters.confidence}
            onChange={(e) => setFilters({ ...filters, confidence: e.target.value })}
            style={{
              padding: '8px 12px',
              border: '1px solid #d1d5db',
              borderRadius: 6,
              fontSize: 13,
              background: '#fff',
              cursor: 'pointer'
            }}
          >
            <option value="all">All Confidence</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>

          <div style={{ flex: 1, position: 'relative', maxWidth: 300 }}>
            <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#9ca3af' }} />
            <input
              type="text"
              placeholder="Search flags..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              style={{
                width: '100%',
                padding: '8px 12px 8px 36px',
                border: '1px solid #d1d5db',
                borderRadius: 6,
                fontSize: 13
              }}
            />
          </div>

          {(filters.tier !== 'all' || filters.category !== 'all' || filters.confidence !== 'all' || filters.search) && (
            <button
              onClick={() => setFilters({ tier: 'all', category: 'all', confidence: 'all', search: '' })}
              style={{
                padding: '8px 12px',
                background: '#f3f4f6',
                border: '1px solid #d1d5db',
                borderRadius: 6,
                fontSize: 13,
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: 6
              }}
            >
              <X size={14} />
              Clear
            </button>
          )}
        </div>}

        {/* Results Count */}
        {flags.length > 0 && <div style={{ marginBottom: 16, fontSize: 14, color: '#6b7280' }}>
          Showing <strong>{filteredAndSortedFlags.length}</strong> of {flags.length} flags
        </div>}

        {/* Flags Table */}
        {flags.length > 0 && <div style={{
          background: '#ffffff',
          border: '1px solid #e5e7eb',
          borderRadius: 8,
          overflow: 'hidden'
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: '#f9fafb', borderBottom: '2px solid #e5e7eb' }}>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280', cursor: 'pointer' }}
                    onClick={() => handleSort('tier')}>
                  Tier {sortConfig.key === 'tier' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                </th>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280', cursor: 'pointer' }}
                    onClick={() => handleSort('category')}>
                  Category {sortConfig.key === 'category' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                </th>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280', cursor: 'pointer' }}
                    onClick={() => handleSort('flag_type')}>
                  Flag Type {sortConfig.key === 'flag_type' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                </th>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280', cursor: 'pointer' }}
                    onClick={() => handleSort('entity')}>
                  Entity {sortConfig.key === 'entity' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                </th>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280', cursor: 'pointer' }}
                    onClick={() => handleSort('confidence')}>
                  Confidence {sortConfig.key === 'confidence' && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                </th>
                <th style={{ padding: '16px', textAlign: 'left', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', color: '#6b7280' }}>
                  Delta
                </th>
                <th style={{ padding: '16px', width: 40 }}></th>
              </tr>
            </thead>
            <tbody>
              {filteredAndSortedFlags.map((flag) => {
                const isExpanded = expandedFlags.has(flag.id);
                const tier = tierConfig[flag.tier] || tierConfig[4];
                const conf = confidenceConfig[flag.confidence] || confidenceConfig['Medium'];
                
                return (
                  <React.Fragment key={flag.id}>
                    <tr 
                      style={{ 
                        borderBottom: '1px solid #f3f4f6',
                        cursor: 'pointer',
                        background: isExpanded ? tier.bg : '#ffffff',
                        transition: 'background 0.2s'
                      }}
                      onClick={() => toggleFlag(flag.id)}
                    >
                      <td style={{ padding: '16px' }}>
                        <span style={{
                          display: 'inline-block',
                          padding: '4px 10px',
                          borderRadius: 4,
                          fontSize: 11,
                          fontWeight: 700,
                          background: tier.bg,
                          color: tier.color,
                          border: `1px solid ${tier.border}`
                        }}>
                          {flag.tier}
                        </span>
                      </td>
                      <td style={{ padding: '16px', fontSize: 13, fontWeight: 600, color: '#111827' }}>
                        {flag.category}
                      </td>
                      <td style={{ padding: '16px', fontSize: 13, color: '#374151' }}>
                        {flag.flag_type}
                      </td>
                      <td style={{ padding: '16px', fontSize: 13, color: '#111827', fontWeight: 600 }}>
                        {flag.entity}
                      </td>
                      <td style={{ padding: '16px' }}>
                        <span style={{
                          display: 'inline-block',
                          padding: '4px 10px',
                          borderRadius: 4,
                          fontSize: 11,
                          fontWeight: 600,
                          background: conf.bg,
                          color: conf.color
                        }}>
                          {flag.confidence}
                        </span>
                      </td>
                      <td style={{ padding: '16px', fontSize: 13, color: '#4b5563' }}>
                        {flag.delta}
                      </td>
                      <td style={{ padding: '16px', textAlign: 'center' }}>
                        {isExpanded ? <ChevronUp size={18} color="#6b7280" /> : <ChevronDown size={18} color="#6b7280" />}
                      </td>
                    </tr>
                    {isExpanded && (
                      <tr>
                        <td colSpan={7} style={{ padding: 0, background: tier.bg }}>
                          <div style={{ padding: '24px 32px', borderTop: `2px solid ${tier.border}` }}>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
                              <div>
                                <div style={{
                                  fontSize: 11,
                                  fontWeight: 700,
                                  textTransform: 'uppercase',
                                  letterSpacing: '0.5px',
                                  color: '#6b7280',
                                  marginBottom: 12
                                }}>Q2 2025 (Prior Quarter)</div>
                                <div style={{
                                  padding: '16px',
                                  background: '#ffffff',
                                  borderRadius: 6,
                                  borderLeft: '4px solid #d1d5db',
                                  fontSize: 13,
                                  lineHeight: 1.7,
                                  color: '#374151',
                                  fontStyle: 'italic'
                                }}>
                                  {flag.call_q2_evidence ? `"${flag.call_q2_evidence}"` : '—'}
                                </div>
                              </div>
                              <div>
                                <div style={{
                                  fontSize: 11,
                                  fontWeight: 700,
                                  textTransform: 'uppercase',
                                  letterSpacing: '0.5px',
                                  color: '#6b7280',
                                  marginBottom: 12
                                }}>Q3 2025 (Current Quarter)</div>
                                <div style={{
                                  padding: '16px',
                                  background: flag.call_q3_evidence ? '#ffffff' : tier.bg,
                                  borderRadius: 6,
                                  borderLeft: `4px solid ${flag.call_q3_evidence ? '#d1d5db' : tier.border}`,
                                  fontSize: 13,
                                  lineHeight: 1.7,
                                  color: flag.call_q3_evidence ? '#374151' : tier.color,
                                  fontStyle: 'italic'
                                }}>
                                  {flag.call_q3_evidence ? `"${flag.call_q3_evidence}"` : '⚠ Not mentioned'}
                                </div>
                              </div>
                            </div>
                            
                            {/* Question that triggered this flag */}
                            {flag.question && (
                              <div style={{
                                background: '#f9fafb',
                                borderRadius: 8,
                                padding: '16px',
                                border: '1px solid #e5e7eb'
                              }}>
                                <div style={{
                                  fontSize: 11,
                                  fontWeight: 700,
                                  textTransform: 'uppercase',
                                  letterSpacing: '0.5px',
                                  color: '#6b7280',
                                  marginBottom: 8
                                }}>
                                  Analysis Question
                                </div>
                                <div style={{
                                  fontSize: 13,
                                  lineHeight: 1.6,
                                  color: '#374151'
                                }}>
                                  {flag.question}
                                </div>
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>}

        {flags.length > 0 && filteredAndSortedFlags.length === 0 && (
          <div style={{
            textAlign: 'center',
            padding: '60px 20px',
            color: '#9ca3af',
            fontSize: 14
          }}>
            No flags match your filters. Try adjusting your search criteria.
          </div>
        )}

      </main>

      {showPodcast && (
        <div style={{
          width: '50%',
          borderLeft: '1px solid #e5e7eb',
          background: '#fff',
          position: 'relative',
          display: 'flex',
          flexDirection: 'column'
        }}>
          <div style={{
            padding: '12px 16px',
            borderBottom: '1px solid #e5e7eb',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <span style={{ fontWeight: 600, fontSize: 14, color: '#374151' }}>🎙️ Podcast Creator</span>
            <button
              onClick={() => setShowPodcast(false)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: 4,
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <X size={18} color="#6b7280" />
            </button>
          </div>
          <iframe
            src="https://csv-to-podcast-bot.lovable.app/"
            style={{
              flex: 1,
              border: 'none',
              width: '100%',
              minHeight: 'calc(100vh - 120px)'
            }}
            title="Podcast Creator"
          />
        </div>
      )}
      </div>
    </div>
  );
}
