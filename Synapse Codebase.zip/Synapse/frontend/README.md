# Synapse - Earnings Call Analysis App

A React application for analyzing earnings call transcripts and identifying key signals and themes.

## Getting Started

### Install Dependencies

```bash
npm install
```

### Run Development Server

```bash
npm run dev
```

The app will be available at `http://localhost:5173`

### Build for Production

```bash
npm run build
```

### Preview Production Build

```bash
npm run preview
```

## Features

- Interactive theme cards with expandable sections
- Signal flagging with before/after quote comparisons
- Risk level indicators
- Clean, modern UI with serif typography
- Export functionality (UI ready)

## Tech Stack

- React 18
- Vite
- Lucide React (icons)


